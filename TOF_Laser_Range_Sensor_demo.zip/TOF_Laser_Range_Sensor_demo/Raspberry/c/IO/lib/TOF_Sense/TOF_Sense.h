#ifndef _TOF_SENSE_H_
#define _TOF_SENSE_H_

#include "DEV_Config.h"

#define IO_H 6
#define IO_L 5




void TOF_IO_init();
void TOF_IO_Demo();






















#endif